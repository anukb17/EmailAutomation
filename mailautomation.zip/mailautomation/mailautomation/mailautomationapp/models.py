from django.db import models

# Create your models here.
class UserDetails(models.Model):
    user_name = models.CharField(max_length=40)
    user_email = models.EmailField(max_length=40)
    user_city = models.CharField(max_length=40)
    def __str__(self):
        return self.user_name+" "+self.user_email+" "+self.user_city