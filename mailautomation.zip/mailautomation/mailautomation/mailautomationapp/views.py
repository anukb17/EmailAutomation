from django.shortcuts import render
from .models import UserDetails
from django.core.mail import send_mail
import datetime
import time
import requests
# Create your views here.
def index(request):
    name = request.POST.get('name',False)
    email = request.POST.get('email',False)
    city = request.POST.get('city',False)


    appid = 'ae1433bbc6409ab2088a893db1dcb971'
    URL = 'http://api.openweathermap.org/data/2.5/weather'
    PARAMS = {'q':city,'appid':appid,'units':'metric'}
    r = requests.get(url = URL, params = PARAMS)
    res = r.json()
    description = res['weather'][0]['description']
    icon = res['weather'][0]['icon']
    temp = res['main']['temp']
    day = datetime.date.today()
    #time = datetime.datetime(hour)
    t = time.localtime()
    current_time = time.strftime("%H:%M:%S", t)

    details = UserDetails(user_name=name, user_email= email, user_city=city)
    details.save()
    
    send_mail('Hello '+ str(name)+'  Interested in our services!',"Temperature in your city is: "+str(temp)+" and time is: "+ str(current_time)+" and weather is: " + str(description), 'anukb17@gmail.com', [email], fail_silently = False)
    return render(request, 'mailautomationapp/index.html')